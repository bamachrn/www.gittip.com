namespace Sass {

  char* copy_c_str(const char*);

}
