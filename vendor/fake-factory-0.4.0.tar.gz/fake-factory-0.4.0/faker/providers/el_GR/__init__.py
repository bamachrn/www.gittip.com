# coding=utf-8
"""
fake.address():              Μαστρογιαννίδου 7,
                             ΤΚ 36777 Αλεξανδρούπολη
fake.line_address():         Αργυροπούλου 3, 34924 Δράμα
fake.street_name():          Αρδείας
fake.street_address():       Λεωφ. Ευόσμου 44
fake.building_number():      131
fake.postcode():             ΤΚ 991 51
fake.city():                 Καστοριά
fake.region():               Πέλλα
fake.country():              Μπρουνέι
fake.latitude():             38.818785
fake.longitude():            27.367441
fake.latlng():               (36.706833, 28.523434)

fake.name():                 Θεοδώρα Αλεξανδράκη
fake.name_male():            Σόλων-Αγγελής Πετράκης
fake.name_female():          Μαρία Ξυγκάκου
fake.first_name():           Μάριος
fake.first_name_male():      Επαμεινώνδας
fake.first_name_female():    Ρεβέκα
fake.last_name():            Φραγκόπουλος
fake.last_name_male():       Αποστολάκης
fake.last_name_female():     Χαλκίδου

fake.text():                 Πιο προγραμματιστής παραδώσεις γραμμή στη νιρβάνα
                             κι. Πολύ έγραψες ημέρα τι συνεντεύξεις. Γραμμής
                             βρίσκονται αποθηκευτικού από συνάδελφος μέχρι τα.

fake.phone_number():         210 761 8331

fake.email():                aimilia.lioliopoulou@doukatziskapetanios.gr
fake.free_email():           yzygouris@gmail.com
fake.company_email():        eutychia.tsachaki@ioakeim.gr
fake.user_name():            konstantina.maniotis
fake.url():                  http://www.anastasiou.org/
"""
