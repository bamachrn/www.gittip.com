===========================================
``exceptions``: Custom exception subclasses
===========================================

.. automodule:: invoke.exceptions
