======================================
``Parser``: Core parsing state machine
======================================

.. automodule:: invoke.parser
