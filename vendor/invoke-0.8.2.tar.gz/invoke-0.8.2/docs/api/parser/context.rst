=========================================
``Context``: Task-oriented parser context
=========================================

.. automodule:: invoke.parser.context
