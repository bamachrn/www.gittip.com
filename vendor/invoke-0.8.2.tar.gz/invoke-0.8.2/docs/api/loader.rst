============================================
``Loader``: Loading of task definition files
============================================

.. autoclass:: invoke.loader.Loader
    :special-members:
    :exclude-members: __weakref__
