=============================================
``Runner`` & ``run``: Executes shell commands
=============================================

.. automodule:: invoke.runner
    :member-order: bysource
