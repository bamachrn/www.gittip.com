============================================
``Context``: Configuration & execution state
============================================

.. automodule:: invoke.context
