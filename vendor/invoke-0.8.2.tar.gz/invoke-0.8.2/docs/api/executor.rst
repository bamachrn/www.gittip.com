======================================
``Executor``: Task execution machinery
======================================

.. autoclass:: invoke.executor.Executor
