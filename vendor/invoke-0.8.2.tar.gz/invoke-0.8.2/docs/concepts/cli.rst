======================
Command-line interface
======================

.. toctree::
    :glob:

    cli/*
